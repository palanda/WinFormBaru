Simple line icons 2
dribbble: https://dribbble.com/monz 
twitter: @mirkomonti94
created by: Mirko Monti

---
LICENSE,ATTRIBUTION:
You are free to use icon set  in any personal, open-source or commercial work without obligation of  attribution. Do not sell the icon set, host the icon set or rent the icon set (either in existing or modified form).

While attribution is optional, it is always appreciated :)

QUESTIONS, COMMENTS:
Contact me via mirko.monti.94@gmail.com